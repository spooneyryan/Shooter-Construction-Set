# @electricblazor/react

A React + TypeScript component suite: overlays and dialogs, a date/time picker, a colour picker, a
multi-step wizard with conditional logic, a guided product tour, and visual editors for the last two.

**Version:** 0.9.2 · MIT · React 18 or 19

Ported from [ElectricBlazor](https://dev.azure.com/MorrisonHotel/ElectricBlazor), a Blazor suite of
the same components. The two share one theme stylesheet, so a Blazor app and a React app can sit in
the same product and look like one thing. You do not need to know or care about the Blazor half to
use this.

## Install

```bash
npm install @electricblazor/react
```

React and React DOM are peer dependencies — this package brings no runtime dependencies of its own.

## Styles

Two stylesheets, and you need both unless you are supplying your own tokens:

```ts
import "@electricblazor/react/theme.css";  // design tokens: colour, spacing, radius, z-layers
import "@electricblazor/react/styles.css"; // the component rules, all var(--eb-*) references
```

They are separate on purpose. `theme.css` is the token layer shared with the Blazor suite, so a
hybrid app already loading it must not load a second copy; and an app with its own token values wants
the components without it. Import `theme.css` first, or override the tokens after it.

Nine skins ship in the theme. Set one on the document and every component follows:

```ts
document.documentElement.setAttribute("data-eb-theme", "electric");
```

`auto` resolves to a light or dark skin from `prefers-color-scheme`. `EbThemeSwitcher` is a ready-made
picker for all nine.

## Use

```tsx
import { EbButton, EbDialog, OverlayStackProvider } from "@electricblazor/react";

function Example() {
    const [open, setOpen] = useState(false);

    return (
        <OverlayStackProvider>
            <EbButton variant="primary" onClick={() => setOpen(true)}>Open</EbButton>
            <EbDialog open={open} title="Hello" onClose={() => setOpen(false)}>
                Anything you like.
            </EbDialog>
        </OverlayStackProvider>
    );
}
```

`OverlayStackProvider` wraps anything that stacks — dialogs, popovers, tours. It hands out z-indices
so a dialog opened from a popover lands above it. One near the root of the app is enough.

## Entry points

The suite is one package with subpaths, so the pieces cannot drift out of version with each other.
Import only what you use; the rest is never bundled.

| Import | What is in it |
| --- | --- |
| `@electricblazor/react` | Buttons, cards, accordions, dialogs, popovers, overlays, numeric input, tabbed cards, draggable and resizable boxes, a drag-and-keyboard sortable list, the theme switcher, colour and number helpers |
| `@electricblazor/react/audio` | `EbAudioPlayer` — a gapless two-element audio player with a ten-band equalizer, canvas visualizers, and M3U playlists |
| `@electricblazor/react/datetime` | `EbDateTimePicker`, `EbMonthGrid`, `EbTimePanel`, and the `DateOnly`/`TimeOnly` value types |
| `@electricblazor/react/color` | `EbColorPicker` and the colour model |
| `@electricblazor/react/coolbuttons` | `EbCoolButtonGroup` — a retro segmented toggle bar with single selection |
| `@electricblazor/react/dockdrawers` | `EbEdgeTab` — a drawer docked to a screen edge, with an optional hover-to-reveal tab |
| `@electricblazor/react/graph` | `EbGraph` — an auto-scaling SVG point and line graph, with optional tooltips and a drag-to-scrub readout |
| `@electricblazor/react/wizard` | `EbWizard` — multi-step forms with validation, conditional steps, and resumable sessions |
| `@electricblazor/react/wizardstudio` | `EbWizardStudio`, a visual editor that authors wizard definitions and generates TypeScript |
| `@electricblazor/react/textcleaner` | `EbTextCleanerPanel` — twenty-five checks that clean pasted text: encoding garble, invisible characters, smart punctuation, RTF/PDF/email/spreadsheet artifacts, and a sensitive-data review |
| `@electricblazor/react/texteditor` | `EbTextEditor` — a sanitizing rich-text editor — and `EbCodeEditor`, a plain-text code surface |
| `@electricblazor/react/tile` | `EbTileGrid` — a dashboard board of draggable, resizable tiles that can be combined into tabbed groups |
| `@electricblazor/react/tour` | `EbTour` — guided product tours anchored to live elements |
| `@electricblazor/react/tourstudio` | `EbTourStudio`, the visual tour editor with an element picker |
| `@electricblazor/react/cssdesigner` | `EbCssDesigner`, a live stylesheet editor |
| `@electricblazor/react/loadergame` | `EbLoaderGame` — a playable breakout game as a loading indicator |
| `@electricblazor/react/save` | The save-menu and store abstraction the studios persist through |
| `@electricblazor/react/styles.css` | Every component stylesheet |
| `@electricblazor/react/theme.css` | The design tokens and the nine skins |

## Security note

`EbWizard` and `EbTour` accept **definitions** — plain data describing steps, fields, and validation —
which are meant to be authored by you, or by your own users through the studio components, and stored
somewhere you control.

A wizard field can carry a validation `pattern`, which is compiled to a `RegExp`. The Blazor original
bounds that with a `Regex` match timeout; JavaScript has no equivalent, and no way to interrupt a
running regular expression. A hostile pattern can therefore hang the tab (ReDoS).

**Do not load wizard definitions from untrusted sources.** If you must, validate the patterns before
compiling them, or run the wizard in a worker you can terminate.

Beyond that, the components use no `eval`, no `innerHTML`, and no `dangerouslySetInnerHTML` — enforced
by a lint test rather than by convention. Content passes through React's normal escaping.

## Browser support

**Chrome/Edge 102+, Firefox 112+, Safari 16.4+.**

Two things set that floor, and they fail very differently:

- **Regular-expression lookbehind** (`(?<=…)`, `(?<!…)`), used throughout the text-cleaning checks
  and in URL and punctuation handling. This is the Safari 16.4 constraint, and it is a **hard** one:
  an engine that does not support lookbehind rejects the pattern while *parsing* the file, so the
  module fails to load rather than misbehaving at runtime. There is no feature test that helps.
- **The `inert` attribute**, used by the overlay, the date picker, and the edge-tab drawer to take
  hidden panels out of the tab order. This is the Chrome 102 / Firefox 112 constraint, and it is
  **soft**: an engine that ignores `inert` still gets `aria-hidden`, so the panel is hidden from
  assistive technology and merely remains reachable by Tab.

Below those, the package also uses `structuredClone` and `Array.prototype.at` (Safari 15.4),
`replaceChildren` (Safari 14), `ResizeObserver`, `CSS.escape`, and Unicode property escapes
(`\p{…}`) — all comfortably within the range above.

`Intl.DateTimeFormat.formatToParts` is worth naming separately: the date picker takes its formats,
first-day-of-week, and 12/24-hour clock from `Intl` rather than shipping its own locale data, so it
follows the user's locale with no configuration.

> Earlier releases of this README claimed Chrome 79 / Firefox 63 / Safari 14. That was never quite
> right and became clearly wrong once the text-cleaning checks landed. If you are pinned to an older
> Safari, `@electricblazor/react/texteditor` and `@electricblazor/react/textcleaner` are the entry
> points to avoid; most of the rest of the suite is far less demanding.

## Notes on behaviour

- **Controlled and uncontrolled** both work, the React way: pass `value` to control a component,
  `defaultValue` to let it own its state. Every such prop has a matching `onXChange`.
- **Class names are stable.** Each component wears both a hashed CSS-Modules class and a plain,
  documented one (`eb-button`, `eb-dialog-header`), so you can target it from your own stylesheet and
  it will not break when this package is rebuilt.
- **ESM only.** No CommonJS build.

## Licence

MIT. See [LICENSE](./LICENSE).

---

Porting decisions, the divergence register, and the phase write-ups live in
[PORTING.md](./PORTING.md) — that is a document about how this was built, not about how to use it.
